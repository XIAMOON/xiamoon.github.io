//
//  main1.cpp
//  CreateWindow
//
//  Created by 李乾 on 2018/3/8.
//  Copyright © 2018年 liqian. All rights reserved.
//

#include "glad.h"
#include <GLFW/glfw3.h>
#include <iostream>

static void framebuffer_size_callback(GLFWwindow* window, int width, int height);
static void processInput(GLFWwindow *window);


int main() {
    // 初始化GLFW
    glfwInit();
    // 配置GLFW，设置主版本号。hint：提示
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    // 设置次版本号
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    // 设置OpenGL使用核心模式(Core-profile)
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    // 向前兼容
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    
    // 创建窗口对象
    GLFWwindow *window = glfwCreateWindow(800, 600, "LearnOpenGL", NULL, NULL);
    if (window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    // 将window设置为当前线程的主上下文
    glfwMakeContextCurrent(window);
    
    
    // GLAD：管理OpenGL函数指针
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }
    
    // 指定视口位置和大小(像素)。(0, 0)指左下角，下面注册时回调第一次也会调用，所以注释。
//    glViewport(0, 0, 800, 600);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    
    while (!glfwWindowShouldClose(window)) { // 检查GLFW是否被要求退出
        // 检测用户输入或者按键
        processInput(window);
        
        // 渲染指令
        glClearColor(0.2f, 0.3f, 0.3f, 1.0);
        glClear(GL_COLOR_BUFFER_BIT);
        
        // 交换颜色缓冲
        glfwSwapBuffers(window);
        // 检查有没有触发事件（键盘输入、鼠标移动）
        glfwPollEvents();
        
        std::cout << "正在while循环" << std::endl;
    }
    
    
    
    glfwTerminate();
    return 0;
}



// 回调
static void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// 实现输入控制
static void processInput(GLFWwindow *window) {
    // 如果用户按下了esc按键
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
        // 如果按了esc，关闭GLFW
        glfwSetWindowShouldClose(window, true);
    }
}





























