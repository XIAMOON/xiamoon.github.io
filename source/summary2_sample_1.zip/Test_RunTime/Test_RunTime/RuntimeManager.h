//
//  RuntimeManager.h
//  Test_RunTime
//
//  Created by dayHR on 17/3/30.
//  Copyright © 2017年 liqian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

@interface RuntimeManager : NSObject

@end

/* Working with Instances : 实例(object)的使用方法 */
@interface RuntimeManager (Object)

/**
 <#Description#>

 @param obj <#obj description#>
 @return <#return value description#>
 */
+ (Class)object_getClass:(id)obj;

+ (Class)object_setObject:(id)obj forClass:(Class)cls;

+ (BOOL)object_isClass:(id)obj;

+ (NSString *)object_getClassName:(id)obj;

+ (id)object_getIvarValueWithIvar:(Ivar)ivar ofObject:(id)obj;

+ (void)object_setIvarValueWithObject:(id)obj ivar:(Ivar)ivar value:(id)value;

+ (void)object_setIvarWithStrongDefaultWithObject:(id)obj ivar:(Ivar)ivar value:(id)value;

@end


/* Obtaining Class Definitions : 获取类的定义 */
@interface RuntimeManager (Objc)

+ (Class)objc_getClassWithClassName:(const char *)className;

+ (Class)objc_getMetaClassWithClassName:(const char *)className;

+ (Class)objc_lookUpClassWithClassName:(const char *)className;

+ (Class)objc_getRequiredClassWithClassName:(const char *)className;

@end


/* Working with Classes : 类(Class )的使用方法 */
@interface RuntimeManager (Class)

+ (NSString *)class_getClassNameWithClass:(Class)cls;

+ (BOOL)class_isMetaClass:(Class)cls;

+ (Class)class_getSuperclass:(Class)cls;

+ (Class)class_setSuperclassWithClass:(Class)cls superClass:(Class)newSuper
__OSX_DEPRECATED(10.5, 10.5, "not recommended")
__IOS_DEPRECATED(2.0, 2.0, "not recommended")
__TVOS_DEPRECATED(9.0, 9.0, "not recommended")
__WATCHOS_DEPRECATED(1.0, 1.0, "not recommended");

+ (int)class_getVersion:(Class)cls;

+ (void)class_setVersion:(int)version forClass:(Class)cls;

+ (NSUInteger)class_getInstanceSize:(Class)cls;


/**
 返回一个给定类的指定的实例变量的Ivar。

 @param cls 您希望获得其实例变量的类。
 @param varName 要获取的实例变量定义的名称。
 @return 一个Ivar数据结构指针，这个数据结构包含指定名称的实例变量的信息。
 */
+(Ivar)class_getInstanceVariableWithClass:(Class)cls varName:(NSString *)varName;


/**
 返回一个给定类的指定类变量的Ivar。

 @param cls 你想要获取的类变量的类
 @param varName 要获取的类变量的名称
 @return 一个Ivar数据结构指针，这个数据结构包含指定名称的类变量的信息。
 */
+ (Ivar)class_getClassVariableWithClass:(Class)cls varName:(NSString *)varName;


/**
 描述由类声明的实例变量。

 @param cls 被检查的类
 @param outCount 将会被返回，返回值为数组的长度。如果不传入outCount，那么就不会返回数组的长度
 @return 一个类型为Ivar的指针数组，这个Ivar为类的实例变量。但是不包含其父类的实例变量。这个数组包含着outCount个跟着终止符的指针。你必须用free()函数释放这个数组
 
 如果这个类没有实例变量，或者cls为Nil，那么将会返回NULL，且*outCount为0.
 */
+ (Ivar *)class_copyIvarListWithClass:(Class)cls outCount:(unsigned int *)outCount;


/**
 返回给定类的指定的实例方法

 @param cls 被检查的类
 @param selName 你想要检索的方法的方法名
 @return 返回一个与指定的类的指定的方法名的方法的实现相对应的方法，如果这个类或者其父类都不包含指定方法名的实例方法，将会返回NULL

 注意：这个方法将会检索父类的方法，但是class_copyMethodList不会检索父类
 */
+ (Method)class_getInstanceMethodWithClass:(Class)cls selector:(SEL)selName;


/**
 返回给定类的指定的类方法

 @param cls <#cls description#>
 @param selName <#selName description#>
 @return <#return value description#>
 */
+ (Method)class_getClassMethodWithClass:(Class)cls selector:(SEL)selName;



/**
 <#Description#>

 @param cls <#cls description#>
 @param selName <#selName description#>
 @return <#return value description#>
 */
+ (IMP)class_getMethodImplementationWithClass:(Class)cls selector:(SEL)selName;


+ (IMP)class_getMethodImplementation_stretWithClass:(Class)cls selector:(SEL)selName;

+ (BOOL)class_respondsToSelectorWithClass:(Class)cls selector:(SEL)selName;

+ (Method *)class_copyMethodListWithClass:(Class)cls outCount:(unsigned int *)outCount;

+ (BOOL)class_conformsToProtocolWithClass:(Class)cls protocol:(Protocol *)protocol;

+ (objc_property_t)class_getPropertyWithClass:(Class)cls propertyName:(NSString *)propertyName;

+ (const uint8_t *)class_getIvarLayout:(Class)cls;

+ (const uint8_t *)class_getWeakIvarLayout:(Class)cls;

+ (BOOL)class_addMethodWithClass:(Class)cls selName:(SEL)selName imp:(IMP)imp types:(const char *)types;

+ (IMP)class_replaceMethodWithClass:(Class)cls selName:(SEL)selName imp:(IMP)imp types:(const char *)types;

+ (BOOL)class_addIvarWithClass:(Class)cls name:(NSString *)name size:(size_t)size alignment:(uint8_t)alignment types:(const char *)types;

+ (BOOL)class_addProtocolWithClass:(Class)cls protovol:(Protocol *)protocol;




@end

