
//
//  ViewControllersViewController.m
//  Test_RunTime
//
//  Created by dayHR on 17/3/31.
//  Copyright © 2017年 liqian. All rights reserved.
//

#import "ViewControllersViewController.h"
#import "RuntimeManager.h"
#import "Person.h"

@interface ViewControllersViewController ()

@end

@implementation ViewControllersViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    //------------------------------------------- 实例(object)的使用方法：/* Working with Instances */ -------------------------------------------//
    //    Class class = [RuntimeManager object_getClass:self];
    Class class = object_getClass(self); // 通过一个对象获取这个对象的类定义
    
    Class class2 = object_setClass(self, [self class]); // 给一个对象设置一个新的类定义，返回设置之前对象的类定义
    
    BOOL isClass = object_isClass(self); // 判断一个对象是否是是一个类或者元类
    
    const char *className = object_getClassName(self); // 通过一个对象获取这个对象所对应的类名
    
    Ivar ivar;
    id value = object_getIvar(self, ivar); // 通过一个对象和对象的实例变量名称，获取这个实例变量的值
    
    object_setIvar(self, ivar, @"张三"); // 设置对象中一个实例变量的值
    
#warning - 这个不知道是什么意思
    object_setIvarWithStrongDefault(self, ivar, @"李四");
    
    
    
    //------------------------------------------- 获取类的定义：/* Obtaining Class Definitions */ -------------------------------------------//
    Class class3 = objc_getClass("ViewController"); // 通过类名获取一个类的定义
    
    Class class4 = objc_getMetaClass("ViewController"); // 通过类名获取一个类的元类
    
    Class class5 = objc_lookUpClass("ViewController"); // 通过类名获取一个类的定义
    
    Class class6 = objc_getRequiredClass("ViewController"); // 等同于objc_getClass，不同的是，如果没有找到这个类，系统将会杀死进程，这个方法被ZeroLink使用，未能找到这个类将是一个没有zerolink的编译时链接错误
    
#warning - 这个不知道是什么意思
    //    int count = objc_getClassList([class, class2, class3], 3);
    
#warning - 这个不知道是什么意思
    //创建并返回指向所有已注册类定义的指针列表，注释中提示让我们和objc_getClassList一起看
    //    unsigned int count;
    //    Class *class7 = objc_copyClassList(&count);
    
    
    
    //------------------------------------------- 类(Class )的使用方法：/* Working with Classes */ -------------------------------------------//
    const char *className2 = class_getName([self class]); // 通过类对象返回类的名字
    
    BOOL isMetaClass = class_isMetaClass([self class]); // 通过类对象判断这个类是否是一个元类
    
    Class class8 = class_getSuperclass([self class]); // 通过类对象返回这个类的父类
    
#warning - 这个方法是不推荐用的
    Class class9 = class_setSuperclass([self class], [Person class]); // 设置一个类的父类
    
    int version = class_getVersion([self class]); // 获取一个类的版本号
    
    class_setVersion([self class], 2.0); // 设置一个类的版本号
    
    // size_t：C语言定义的，等同于 32位系统的 unsigned int 或者 64位系统的 unsigned long int，等同于NSUInteger
    size_t size = class_getInstanceSize([self class]); // 返回一个类的大小
    
    Ivar ivar2 = class_getInstanceVariable([self class], "_string1"); //返回一个类的实例变量
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
