//
//  RuntimeManager.m
//  Test_RunTime
//
//  Created by dayHR on 17/3/30.
//  Copyright © 2017年 liqian. All rights reserved.
//

#import "RuntimeManager.h"

@implementation RuntimeManager
@end


@implementation RuntimeManager (Object)

+ (Class)object_getClass:(id)obj {
    Class class = object_getClass(obj);
    return class;
}

+ (Class)object_setObject:(id)obj forClass:(Class)cls {
    Class class = object_setClass(obj, cls);
    return class;
}

+ (BOOL)object_isClass:(id)obj {
    BOOL isClass = object_isClass(obj);
    return isClass;
}

+ (NSString *)object_getClassName:(id)obj {
    const char *className = object_getClassName(obj);
    return [NSString stringWithUTF8String:className];
}

+ (id)object_getIvarValueWithIvar:(Ivar)ivar ofObject:(id)obj {
    id value = object_getIvar(obj, ivar);
    return value;
}

+ (void)object_setIvarValueWithObject:(id)obj ivar:(Ivar)ivar value:(id)value {
    object_setIvar(obj, ivar, value);
}

+ (void)object_setIvarWithStrongDefaultWithObject:(id)obj ivar:(Ivar)ivar value:(id)value {
    object_setIvarWithStrongDefault(obj, ivar, value);
}

@end



@implementation RuntimeManager (Objc)

+ (Class)objc_getClassWithClassName:(const char *)className {
    Class class = objc_getClass(className);
    return class;
}

+ (Class)objc_getMetaClassWithClassName:(const char *)className {
    Class class = objc_getMetaClass(className);
    return class;
}

+ (Class)objc_lookUpClassWithClassName:(const char *)className {
    Class class = objc_lookUpClass(className);
    return class;
}

+ (Class)objc_getRequiredClassWithClassName:(const char *)className {
    Class class = objc_getRequiredClass(className);
    return class;
}

#warning - 这个不知道是什么意思
//    int count = objc_getClassList([class, class2, class3], 3);

#warning - 这个不知道是什么意思
//创建并返回指向所有已注册类定义的指针列表，注释中提示让我们和objc_getClassList一起看
//    unsigned int count;
//    Class *class7 = objc_copyClassList(&count);

@end



@implementation RuntimeManager (Class)

+ (NSString *)class_getClassNameWithClass:(Class)cls {
    const char *className = class_getName(cls);
    return [NSString stringWithUTF8String:className];
}

+ (BOOL)class_isMetaClass:(Class)cls {
    BOOL isMetaClass = class_isMetaClass(cls);
    return isMetaClass;
}

+ (Class)class_getSuperclass:(Class)cls {
    Class class = class_getSuperclass(cls);
    return class;
}

+ (Class)class_setSuperclassWithClass:(Class)cls superClass:(Class)newSuper {
    Class oldSuper = class_setSuperclass(cls, newSuper);
    return oldSuper;
}

+ (int)class_getVersion:(Class)cls {
    int version = class_getVersion(cls);
    return version;
}

+ (void)class_setVersion:(int)version forClass:(Class)cls {
    class_setVersion(cls, version);
}

+ (NSUInteger)class_getInstanceSize:(Class)cls {
    size_t size = class_getInstanceSize(cls);
    return size;
}

+(Ivar)class_getInstanceVariableWithClass:(Class)cls varName:(NSString *)varName {
    Ivar ivar = class_getInstanceVariable(cls, varName.UTF8String);
    return ivar;
}

+ (Ivar)class_getClassVariableWithClass:(Class)cls varName:(NSString *)varName {
    Ivar ivar = class_getClassVariable(cls, varName.UTF8String);
    return ivar;
}

+ (Ivar *)class_copyIvarListWithClass:(Class)cls outCount:(unsigned int *)outCount {
    Ivar *ivars = class_copyIvarList(cls, outCount);
    return ivars;
}

+ (Method)class_getInstanceMethodWithClass:(Class)cls selector:(SEL)selName {
    Method method = class_getInstanceMethod(cls, selName);
    return method;
}

+ (Method)class_getClassMethodWithClass:(Class)cls selector:(SEL)selName {
    Method method = class_getClassMethod(cls, selName);
    return method;
}

+ (IMP)class_getMethodImplementationWithClass:(Class)cls selector:(SEL)selName {
    IMP imp = class_getMethodImplementation(cls, selName);
    return imp;
}

+ (IMP)class_getMethodImplementation_stretWithClass:(Class)cls selector:(SEL)selName {
    IMP imp = class_getMethodImplementation_stret(cls, selName);
    return imp;
}

+ (BOOL)class_respondsToSelectorWithClass:(Class)cls selector:(SEL)selName {
    BOOL response = class_respondsToSelector(cls, selName);
    return response;
}

+ (Method *)class_copyMethodListWithClass:(Class)cls outCount:(unsigned int *)outCount {
    Method *methods = class_copyMethodList(cls, outCount);
    return methods;
}

+ (BOOL)class_conformsToProtocolWithClass:(Class)cls protocol:(Protocol *)protocol {
    BOOL conforms = class_conformsToProtocol(cls, protocol);
    return conforms;
}

#warning - 这个不知道是什么意思
//+ (Protocol *)class_copyProtocolListWithClass:(Class)cls outCount:(unsigned int *)outCount {
//    Protocol *__unsafe_unretained *protocols = class_copyProtocolList(cls, outCount);
//    return protocols;
//}

+ (objc_property_t)class_getPropertyWithClass:(Class)cls propertyName:(NSString *)propertyName {
    objc_property_t property = class_getProperty(cls, propertyName.UTF8String);
    return property;
}

+ (const uint8_t *)class_getIvarLayout:(Class)cls {
    const uint8_t *layout = class_getIvarLayout(cls);
    return layout;
}

+ (const uint8_t *)class_getWeakIvarLayout:(Class)cls {
    const uint8_t *layout = class_getWeakIvarLayout(cls);
    return layout;
}

+ (BOOL)class_addMethodWithClass:(Class)cls selName:(SEL)selName imp:(IMP)imp types:(const char *)types {
    BOOL success = class_addMethod(cls, selName, imp, types);
    return success;
}

+ (IMP)class_replaceMethodWithClass:(Class)cls selName:(SEL)selName imp:(IMP)imp types:(const char *)types {
    IMP replaceMethod = class_replaceMethod(cls, selName, imp, types);
    return replaceMethod;
}

+ (BOOL)class_addIvarWithClass:(Class)cls name:(NSString *)name size:(size_t)size alignment:(uint8_t)alignment types:(const char *)types {
    BOOL success = class_addIvar(cls, name.UTF8String, size, alignment, types);
    return success;
}

+ (BOOL)class_addProtocolWithClass:(Class)cls protovol:(Protocol *)protocol {
    BOOL success = class_addProtocol(cls, protocol);
    return success;
}



@end


