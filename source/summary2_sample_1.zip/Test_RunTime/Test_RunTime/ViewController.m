//
//  ViewController.m
//  Test_RunTime
//
//  Created by 李乾 on 17/3/25.
//  Copyright © 2017年 liqian. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"
#import "RuntimeManager.h"

/*
 struct objc_class {
 Class isa  OBJC_ISA_AVAILABILITY;
 
 #if !__OBJC2__
 Class super_class                                        OBJC2_UNAVAILABLE;
 const char *name                                         OBJC2_UNAVAILABLE;
 long version                                             OBJC2_UNAVAILABLE;
 long info                                                OBJC2_UNAVAILABLE;
 long instance_size                                       OBJC2_UNAVAILABLE;
 struct objc_ivar_list *ivars                             OBJC2_UNAVAILABLE;
 struct objc_method_list **methodLists                    OBJC2_UNAVAILABLE;
 struct objc_cache *cache                                 OBJC2_UNAVAILABLE;
 struct objc_protocol_list *protocols                     OBJC2_UNAVAILABLE;
 #endif
 
 } OBJC2_UNAVAILABLE;
 */

@interface ViewController () {
    NSString *_string1;
    NSInteger num1;
}
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) int age;

-(NSString *)getName;
-(int)getAge;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    unsigned int count;
    
    // 获取属性列表
    /*
    objc_property_t *propertyList = class_copyPropertyList([self class], &count);
    for (unsigned int i = 0; i < count; i ++) {
        objc_property_t property = propertyList[i];
        const char *propertyName = property_getName(property);
        NSLog(@"property---->%@", [NSString stringWithUTF8String:propertyName]);
    }
     */
    
    /*
    // 获取成员变量列表
    Ivar *ivarList = class_copyIvarList([self class], &count);
    for (unsigned int i = 0; i < count; i ++) {
        Ivar ivar = ivarList[i];
        const char *ivarName = ivar_getName(ivar);
        NSLog(@"ivar---->%@", [NSString stringWithUTF8String:ivarName]);
    }
     */
    
    // 获取方法列表
    /*
    Method *methodList = class_copyMethodList([self class], &count);
    for (unsigned int i = 0; i < count; i ++) {
        Method method = methodList[i];
        SEL selName = method_getName(method);
        NSLog(@"method---->%@", NSStringFromSelector(selName));
    }
    */
    
    
    //获取协议列表
    __unsafe_unretained Protocol **protocolList = class_copyProtocolList([self class], &count);
    for (unsigned int i; i<count; i++) {
        Protocol *myProtocal = protocolList[i];
        const char *protocolName = protocol_getName(myProtocal);
        NSLog(@"protocol---->%@", [NSString stringWithUTF8String:protocolName]);
    }
     
    
    /*
    [self class];
    ((Class (*)(id, SEL))(void *)objc_msgSend)    (  (id)self, sel_registerName("class")  )
     
    id objc_msgSend(id self, SEL op, ...);
     */
    
    
    /*
    [super class];
    ((Class (*)(__rw_objc_super *, SEL))(void *)objc_msgSendSuper)   (  (__rw_objc_super){ (id)self, (id)class_getSuperclass(objc_getClass("Son"))},     sel_registerName("class")    )
     
     id objc_msgSendSuper(struct objc_super *super, SEL op, ...);
     
     struct objc_super {
         __unsafe_unretained id receiver;
         __unsafe_unretained Class super_class;
     };
     
     
    */
    
}





-(NSString *)getName {
    return @"张三";
}

-(int)getAge {
    return 20;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
