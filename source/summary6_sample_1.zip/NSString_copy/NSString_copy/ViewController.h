//
//  ViewController.h
//  NSString_copy
//
//  Created by dayHR on 17/4/10.
//  Copyright © 2017年 liqian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

