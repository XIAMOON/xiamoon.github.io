//
//  ViewController.m
//  NSString_copy
//
//  Created by dayHR on 17/4/10.
//  Copyright © 2017年 liqian. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, weak) NSString *strongString;
@property (nonatomic, copy) NSString *copyedString;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    NSString *str = [NSString stringWithFormat:@"123"];
    NSMutableString *str = [NSMutableString stringWithFormat:@"123"];
    self.strongString = str;
    self.copyedString = str;
    
    [str appendString:@"abc"];
    
    str = NULL;
    
    NSLog(@"str：%@，%#x，%p", str, str, &str);
    NSLog(@"strongString：%@，%#x，%p", _strongString, _strongString, &_strongString);
    NSLog(@"copyedString：%@，%#x，%p", _copyedString, _copyedString, &_copyedString);
}

-(void)viewDidAppear:(BOOL)animated {
    NSInteger length = [_strongString length];
    NSLog(@"strongString：%@，%#x，%p", _strongString, _strongString, &_strongString);
    NSLog(@"copyedString：%@，%#x，%p", _copyedString, _copyedString, &_copyedString);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
