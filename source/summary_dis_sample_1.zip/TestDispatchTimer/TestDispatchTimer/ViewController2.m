//
//  ViewController2.m
//  TestDispatchTimer
//
//  Created by 李乾 on 2018/4/25.
//  Copyright © 2018年 liqian. All rights reserved.
//

#import "ViewController2.h"

@interface ViewController2 () {
    dispatch_source_t _refreshSoundPowerTimer;
}

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _refreshSoundPowerTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
    dispatch_source_set_timer(_refreshSoundPowerTimer, DISPATCH_TIME_NOW, 0.5 * NSEC_PER_SEC, 0.0);
    dispatch_source_set_event_handler(_refreshSoundPowerTimer, ^{
        
    });
    
//    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(handleBackAction)];
//    self.navigationItem.leftBarButtonItem = leftItem;
}

- (void)handleBackAction {

//    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)start:(id)sender {
    dispatch_resume(_refreshSoundPowerTimer);
}

- (IBAction)suspend:(id)sender {
    dispatch_suspend(_refreshSoundPowerTimer);
}

- (void)dealloc {
    dispatch_source_cancel(_refreshSoundPowerTimer);
    dispatch_resume(_refreshSoundPowerTimer);
    _refreshSoundPowerTimer = nil;
}

@end
