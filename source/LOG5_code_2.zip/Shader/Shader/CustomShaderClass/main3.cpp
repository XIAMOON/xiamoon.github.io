//
//  main.cpp
//  Shader
//
//  Created by 李乾 on 2018/3/10.
//  Copyright © 2018年 liqian. All rights reserved.
//

#include "glad.h"
#include <GLFW/glfw3.h>
#include "CustomShader.hpp"
#include <cmath>
#include <iostream>

static void framebuffer_size_callback(GLFWwindow* window, int width, int height);
static void processInput(GLFWwindow *window);

int main() {
    
#pragma mark - 初始化、配置GLFW
    // 初始化GLFW
    glfwInit();
    // 配置GLFW，设置主版本号。hint：提示
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    // 设置次版本号
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    // 设置OpenGL使用核心模式(Core-profile)
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    // 向前兼容
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    
#pragma mark - 创建及配置窗口对象
    // 创建窗口对象
    GLFWwindow *window = glfwCreateWindow(800, 600, "LearnOpenGL", NULL, NULL);
    if (window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    // 将window设置为当前线程的主上下文
    glfwMakeContextCurrent(window);
    
    // 指定视口位置和大小(像素)。(0, 0)指左下角，下面注册时回调第一次也会调用，所以注释。
    //    glViewport(0, 0, 800, 600);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    
    // GLAD：管理OpenGL函数指针
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }
    
#pragma mark - 创建、编译着色器，创建着色器程序对象
    Shader Shader("3.3.shader.vs", "3.3.shader.fs");
    
#pragma mark - 顶点数据，注意：现在是画正方形
    float vertices[] = {
        // 位置                // 颜色
        0.5f, 0.5f, 0.0f,   1.0f, 0.0f, 0.0f, // 右上角
        0.5f, -0.5f, 0.0f,  0.0f, 1.0f, 0.0f, // 右下角
        -0.5f, -0.5f, 0.0f, 0.0f, 0.0f, 1.0f, // 左下角
        -0.5f, 0.5f, 0.0f,  0.0f, 1.0f, 0.0f // 左上角
    };
    unsigned int indices[] = { // 注意索引从0开始! ，里面的数字代表取上述数组的第几行。
        0, 1, 3, // 第一个三角形
        1, 2, 3  // 第二个三角形
    };
#pragma mark - 创建顶点数组对象、顶点缓冲对象
    unsigned int VBO, VAO, EBO;
    // 创建VAO
    glGenVertexArrays(1, &VAO);
    // 绑定VAO
    glBindVertexArray(VAO);
    //===========================================
    
    // 创建VBO
    glGenBuffers(1, &VBO);
    // 复制顶点数组到缓冲中供OpenGL使用
    // 把VBO绑定到缓冲类型为顶点缓冲对象的缓冲上：GL_ARRAY_BUFFER。绑定完成后，我们使用的任何在GL_ARRAY_BUFFER目标上的缓冲调用都会作用到当前绑定的缓冲(VBO)。
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    // 把vertices数据复制到顶点缓冲对象VBO中。
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    //===========================================
    
    // 创建EBO
    glGenBuffers(1, &EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    
#pragma mark - 链接、解析顶点属性(位置属性)
    // 设置顶点属性指针
    // 每一个顶点属性从一个VBO管理的内存中获得它的数据
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)0);
    // 启用顶点属性
    glEnableVertexAttribArray(0);
    
#pragma mark - 链接、解析颜色属性
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)(3*sizeof(float)));
    glEnableVertexAttribArray(1);
    
#pragma mark - 解绑
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    
#pragma mark - 设置填充模式
    // 使用填充模式话，Default
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    // 使用线框模式画
    //    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    
    
#pragma mark - 循环调用
    while (!glfwWindowShouldClose(window)) { // 检查GLFW是否被要求退出
        // 检测用户输入或者按键
        processInput(window);
        
        // 渲染指令
        glClearColor(0.2f, 0.3f, 0.3f, 1.0);
        glClear(GL_COLOR_BUFFER_BIT);
        
        // 绘制物体
        Shader.use();
        glBindVertexArray(VAO);
        
        // 更新shader的uniform
        float timeValue = glfwGetTime();
        float greenValue = sin(timeValue)*0.5f + 0.5f;
        Shader.setFloat4("ourColor", 0.0f, greenValue, 0.0f, 1.0f);
        
        // 6:顶点个数；0:数组偏移量
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        
        // 交换颜色缓冲
        glfwSwapBuffers(window);
        // 检查有没有触发事件（键盘输入、鼠标移动）
        glfwPollEvents();
        
        std::cout << "正在while循环" << std::endl;
    }
    
    // 释放资源
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
    
    // 清除所有创建的GLFW资源
    glfwTerminate();
    return 0;
}



// 回调
static void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// 实现输入控制
static void processInput(GLFWwindow *window) {
    // 如果用户按下了esc按键
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
        // 如果按了esc，关闭GLFW
        glfwSetWindowShouldClose(window, true);
    }
}


