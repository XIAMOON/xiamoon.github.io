//
//  CustomShader.hpp
//  Shader
//
//  Created by 李乾 on 2018/3/10.
//  Copyright © 2018年 liqian. All rights reserved.
//

#ifndef CustomShader_hpp
#define CustomShader_hpp

#include "glad.h"
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

class Shader {
    unsigned int program;
    
public:
    // 构造函数：构建shader
    Shader(const char *vertexPath, const char *fragmentPath) {
#pragma mark - 1.获取着色器源字符串
        std::string vertexCode;
        std::string fragmentCode;
        std::ifstream vShaderFile;
        std::ifstream fShaderFile;
        // 确保对象可以抛出异常
        vShaderFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);
        fShaderFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);
        try {
            // 打开路径
            vShaderFile.open(vertexPath);
            fShaderFile.open(fragmentCode);
            std::stringstream vShaderSteam, fShaderStream;
            
            // 将文件的缓冲区内容读取到流中
            vShaderSteam << vShaderFile.rdbuf();
            fShaderStream << fShaderFile.rdbuf();
            
            // 关闭文件句柄
            vShaderFile.close();
            fShaderFile.close();
            
            // 将流转换为字符串
            vertexCode = vShaderSteam.str();
            fragmentCode = fShaderStream.str();
        } catch (std::ifstream::failure e) {
            std:: cout << "ERROR::SHADER::FILE_NOT_SUCCESFULLY_READ" << std::endl;
        }
        
        // 获取着色器源字符串
        const char *vertexShaderSource = vertexCode.c_str();
        const char *fragmentShaderSource = fragmentCode.c_str();
        
#pragma mark - 2.创建、编译着色器
        unsigned int vertexShader, fragmentShader;
        
        // 顶点着色器
        vertexShader = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
        glCompileShader(vertexShader);
        checkCompileErrors(vertexShader, "VERTEX");
        
        // 片段着色器
        fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
        glCompileShader(fragmentShader);
        checkCompileErrors(fragmentShader, "FRAGMENT");
        
#pragma mark - 3.Program
        program = glCreateProgram();
        glAttachShader(program, vertexShader);
        glAttachShader(program, fragmentShader);
        glLinkProgram(program);
        checkCompileErrors(program, "PROGRAM");
        
        glDeleteShader(vertexShader);
        glDeleteShader(fragmentShader);
    };
    
    void use() {
        glUseProgram(program);
    };
    
    void setBool(const std::string &name, bool value) const {
        glUniform1i(glGetUniformLocation(program, name.c_str()), (int)value);
    }
    
    void setInt(const std::string &name, bool value) const {
        glUniform1i(glGetUniformLocation(program, name.c_str()), value);
    }
    
    void setFloat(const std::string &name, bool value) const {
        glUniform1f(glGetUniformLocation(program, name.c_str()), value);
    }

    void setFloat4(const char *uniformName, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3) {
        int vertexColorLocation = glGetUniformLocation(program, uniformName);
        glUniform4f(vertexColorLocation, v0, v1, v2, v3);
    }
    
    
    
    private:
    void checkCompileErrors(unsigned int shader, std::string type) {
        int success;
        char infoLog[1024];
        if (type != "PROGRAM") {
            glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
            if (!success) {
                glGetShaderInfoLog(shader, 1024, NULL, infoLog);
                std:: cout << "ERROR: SHADER_COMPILATION_ERROR of type: " << type << "\n" << infoLog << "\n" << std::endl;
            }else {
                glGetProgramiv(shader, GL_LINK_STATUS, &success);
                if (!success) {
                    glGetProgramInfoLog(shader, 2014, NULL, infoLog);
                    std:: cout << "ERROR:PROGRAM_LINKING_ERROR of type: " << type << "\n" << infoLog << "\n" << std::endl;
                }
            }
        }
        
    };
    
};

#endif
