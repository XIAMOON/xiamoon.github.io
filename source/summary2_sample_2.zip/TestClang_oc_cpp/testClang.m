#import <Foundation/Foundation.h>

@interface Father : NSObject
@end

@implementation Father
@end



@interface Son : Father
@end

@implementation Son
-(instancetype)init {
    self = [super init];
    if (self) {
        NSLog(@"%@", NSStringFromClass([self class]));
        NSLog(@"%@", NSStringFromClass([super class]));
    }
    return self;
}
@end
