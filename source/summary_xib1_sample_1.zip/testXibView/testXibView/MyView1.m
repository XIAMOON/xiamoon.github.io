//
//  MyView1.m
//  testXibView
//
//  Created by 李乾 on 2018/4/5.
//  Copyright © 2018年 liqian. All rights reserved.
//

#import "MyView1.h"

@interface MyView1 ()
@property (nonatomic, strong) MyView1 *view;
@end

@implementation MyView1

- (instancetype)init {
    self = [super init];
    if (self) {
        [self _loadView];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self _loadView];
    }
    return self;
}

- (void)_loadView {
    _view = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil].lastObject;
    _view.frame = self.bounds;
    [self addSubview:_view];
}

- (void)setBackgroundColor:(UIColor *)backgroundColor {
    _view.backgroundColor = backgroundColor;
    [super setBackgroundColor:backgroundColor];
}

@end
