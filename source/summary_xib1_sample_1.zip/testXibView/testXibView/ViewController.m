//
//  ViewController.m
//  testXibView
//
//  Created by 李乾 on 2018/4/5.
//  Copyright © 2018年 liqian. All rights reserved.
//

#import "ViewController.h"
#import "MyView1.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet MyView1 *myView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 代码创建的
    MyView1 *view = [MyView1 new];
    view.frame = CGRectMake(20, 100, 375-40, 118);
    [self.view addSubview:view];
    view.backgroundColor = [UIColor orangeColor];
    view.title.text = @"你好啊";
    
    // xib创建的
    _myView.backgroundColor = [UIColor redColor];
    _myView.title.text = @"你好就好";
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
