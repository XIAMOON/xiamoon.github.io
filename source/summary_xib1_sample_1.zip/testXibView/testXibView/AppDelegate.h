//
//  AppDelegate.h
//  testXibView
//
//  Created by 李乾 on 2018/4/5.
//  Copyright © 2018年 liqian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

