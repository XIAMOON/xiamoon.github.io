//
//  ModalViewController2.h
//  TransitionAnimation
//
//  Created by 李乾 on 2018/3/3.
//  Copyright © 2018年 liqian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController2 : UIViewController

@end
