//
//  ViewController.m
//  copy_mutableCopy
//
//  Created by dayHR on 17/4/11.
//  Copyright © 2017年 liqian. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
    NSString *str = [NSString stringWithFormat:@"123"];
    
    NSString *str_copy = str.copy;
    NSMutableString *str_mutableCopy = str.mutableCopy;  // 注意：这里str_mutableCopy是NSMutableString类型的
    [str_mutableCopy appendString:@"abc"];
    
    NSLog(@"str：%@, %#x, %p", str, str, &str);
    NSLog(@"str_copy：%@, %#x, %p", str_copy, str_copy, &str_copy);
    NSLog(@"str_mutableCopy：%@, %#x, %p", str_mutableCopy, str_mutableCopy, &str_mutableCopy);
     */
    
    /*
    NSMutableString *mstr = [NSMutableString stringWithFormat:@"123"];
    
    NSString *mstr_copy = mstr.copy; // 注意：这里mstr_copy是NSString类型的
    NSMutableString *mstr_mutableCopy = mstr.mutableCopy;
    
    [mstr appendString:@"abc"]; // 改变mstr的值
    
    NSLog(@"mstr：%@, %#x, %p", mstr, mstr, &mstr);
    NSLog(@"mstr_copy：%@, %#x, %p", mstr_copy, mstr_copy, &mstr_copy);
    NSLog(@"mstr_mutableCopy：%@, %#x, %p", mstr_mutableCopy, mstr_mutableCopy, &mstr_mutableCopy);
     */
    
    /*
    NSArray *array = @[
                       [NSString stringWithFormat:@"1"],
                       [NSString stringWithFormat:@"2"],
                       [NSMutableString stringWithFormat:@"3"],
                       [NSString stringWithFormat:@"4"]
                       ];
    
    NSArray *array_copy = array.copy;
    NSMutableArray *arr_mutableCopy = array.mutableCopy;
    
    NSMutableString *str = arr_mutableCopy[2];
    [str appendString:@"abc"];
    
    
    
    NSLog(@"array： %#x, %p", array, &array);
    NSLog(@"array_copy： %#x, %p", array_copy, &array_copy);
    NSLog(@"arr_mutableCopy：%#x, %p", arr_mutableCopy, &arr_mutableCopy);

    NSLog(@"---------------------------------------");
    for (NSString *str in array) {
        NSLog(@"array：str：%@, %#x, %p", str, str, &str);
    }
    
    NSLog(@"---------------------------------------");
    for (NSString *str in array_copy) {
        NSLog(@"array_copy：str：%@, %#x, %p", str, str, &str);
    }
    
    NSLog(@"---------------------------------------");
    for (NSString *str in arr_mutableCopy) {
        NSLog(@"arr_mutableCopy：str：%@, %#x, %p", str, str, &str);
    }
    */
    
    
    NSMutableArray *marray = [NSMutableArray arrayWithObjects:
                              [NSString stringWithFormat:@"1"],
                              [NSString stringWithFormat:@"2"],
                              [NSMutableString stringWithFormat:@"3"],
                              [NSString stringWithFormat:@"4"], nil];

    
    NSArray *marray_copy = marray.copy;
    NSMutableArray *marr_mutableCopy = marray.mutableCopy;
    
    NSMutableString *str = marr_mutableCopy[2];
    [str appendString:@"abc"];
    
    
    
    NSLog(@"marray： %#x, %p", marray, &marray);
    NSLog(@"marray_copy： %#x, %p", marray_copy, &marray_copy);
    NSLog(@"marr_mutableCopy：%#x, %p", marr_mutableCopy, &marr_mutableCopy);
    
    NSLog(@"---------------------------------------");
    for (NSString *str in marray) {
        NSLog(@"marray：%@, %#x, %p", str, str, &str);
    }
    
    NSLog(@"---------------------------------------");
    for (NSString *str in marray_copy) {
        NSLog(@"marray_copy：%@, %#x, %p", str, str, &str);
    }
    
    NSLog(@"---------------------------------------");
    for (NSString *str in marr_mutableCopy) {
        NSLog(@"marr_mutableCopy：%@, %#x, %p", str, str, &str);
    }
    
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
