//
//  main1.cpp
//  CreateWindow
//
//  Created by 李乾 on 2018/3/8.
//  Copyright © 2018年 liqian. All rights reserved.
//

#include "glad.h"
#include <GLFW/glfw3.h>
#include <iostream>
 
static void framebuffer_size_callback(GLFWwindow* window, int width, int height);
static void processInput(GLFWwindow *window);

const char *vertexShaderSource = "#version 330 core\n"
"layout (location = 0) in vec3 aPos;\n"
"void main()\n"
"{\n"
"   gl_Position = vec4(aPos.x, aPos.y, aPos.z, 1.0);\n"
"}\0";

const char *fragmentShaderSource = "#version 330 core\n"
"out vec4 FragColor;\n"
"void main()\n"
"{\n"
"   FragColor = vec4(1.0f, 0.5f, 0.2f, 1.0f);\n"
"}\n\0";


int main() {
    
#pragma mark - 初始化、配置GLFW
    // 初始化GLFW
    glfwInit();
    // 配置GLFW，设置主版本号。hint：提示
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    // 设置次版本号
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    // 设置OpenGL使用核心模式(Core-profile)
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    // 向前兼容
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    
#pragma mark - 创建及配置窗口对象
    // 创建窗口对象
    GLFWwindow *window = glfwCreateWindow(800, 600, "LearnOpenGL", NULL, NULL);
    if (window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    // 将window设置为当前线程的主上下文
    glfwMakeContextCurrent(window);
    
    // 指定视口位置和大小(像素)。(0, 0)指左下角，下面注册时回调第一次也会调用，所以注释。
//    glViewport(0, 0, 800, 600);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    
    // GLAD：管理OpenGL函数指针
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }
    
#pragma mark - 创建、编译着色器
    // 创建顶点着色器(vertex shader)
    int vertexShader = glCreateShader(GL_VERTEX_SHADER);
    // 把着色器源码附加到着色器上
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);
    // 检查编译错误
    int success;
    char infoLog[512];
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
    }
    
    // 创建片段着色器(fragment shader)
    int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    // 把着色器源码附加到着色器上
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);
    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
    }
    
#pragma mark - 链接着色器
    // 创建着色器程序对象
    int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    // 检查链接错误
    glGetShaderiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(shaderProgram, 512, NULL, infoLog);
    }
    // 链接之后就不需要了，删除
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
    
#pragma mark - 顶点数据，注意：现在是画正方形
    float vertices[] = {
        0.5f, 0.5f, 0.0f,   // 右上角
        0.5f, -0.5f, 0.0f,  // 右下角
        -0.5f, -0.5f, 0.0f, // 左下角
        -0.5f, 0.5f, 0.0f   // 左上角
    };
    unsigned int indices[] = { // 注意索引从0开始! ，里面的数字代表取上述数组的第几行。
        0, 1, 3, // 第一个三角形
        1, 2, 3  // 第二个三角形
    };
#pragma mark - 创建顶点数组对象、顶点缓冲对象
    unsigned int VBO, VAO, EBO;
    // 创建VAO
    glGenVertexArrays(1, &VAO);
    // 绑定VAO
    glBindVertexArray(VAO);
    //===========================================
    
    // 创建VBO
    glGenBuffers(1, &VBO);
    // 复制顶点数组到缓冲中供OpenGL使用
    // 把VBO绑定到缓冲类型为顶点缓冲对象的缓冲上：GL_ARRAY_BUFFER。绑定完成后，我们使用的任何在GL_ARRAY_BUFFER目标上的缓冲调用都会作用到当前绑定的缓冲(VBO)。
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    // 把vertices数据复制到顶点缓冲对象VBO中。
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    //===========================================
    
    // 创建EBO
    glGenBuffers(1, &EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    
#pragma mark - 链接、解析顶点属性
    // 设置顶点属性指针
    // 每一个顶点属性从一个VBO管理的内存中获得它的数据
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3*sizeof(float), (void*)0);
    // 启用顶点属性
    glEnableVertexAttribArray(0);
    
#pragma mark - 解绑
    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

#pragma mark - 循环调用
    while (!glfwWindowShouldClose(window)) { // 检查GLFW是否被要求退出
        // 检测用户输入或者按键
        processInput(window);
        
        // 渲染指令
        glClearColor(0.2f, 0.3f, 0.3f, 1.0);
        glClear(GL_COLOR_BUFFER_BIT);
        
        // 绘制物体
        glUseProgram(shaderProgram);
        glBindVertexArray(VAO);
        //0:顶点数组其实索引；3:顶点个数
//        glDrawArrays(GL_TRIANGLES, 0, 3);
        // 6:顶点个数；0:数组偏移量
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        
        // 交换颜色缓冲
        glfwSwapBuffers(window);
        // 检查有没有触发事件（键盘输入、鼠标移动）
        glfwPollEvents();
        
        std::cout << "正在while循环" << std::endl;
    }
    
    // 释放资源
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
    
    // 清除所有创建的GLFW资源
    glfwTerminate();
    return 0;
}



// 回调
static void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

// 实现输入控制
static void processInput(GLFWwindow *window) {
    // 如果用户按下了esc按键
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
        // 如果按了esc，关闭GLFW
        glfwSetWindowShouldClose(window, true);
    }
}





























